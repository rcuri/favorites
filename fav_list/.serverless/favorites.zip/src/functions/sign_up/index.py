def sign_up_user(first_name, last_name, email, password):
    try:
        response = password